use crate::{console as c, syscalls as s};
use core::fmt::{self, Write};
static mut SEQ: usize = 0;
struct Writer;
static mut BUFFER: [u8;2048] = [0;2048];
static mut LEN: usize = 0;
impl Write for Writer {
    fn write_str(&mut self, text: &str) -> fmt::Result {
        unsafe {
            assert!(LEN + text.len() <= 2048);
            BUFFER[LEN..LEN+text.len()].copy_from_slice(text.as_bytes());
            LEN += text.len();
        }
        Ok(())
    }
}
fn flush() { unsafe { c::record(&BUFFER[..LEN]); LEN=0; } }
pub fn enter(n:usize,a:&[usize;6],_:usize) {
    if !matches!(n,214|215|222) { return; }
    unsafe { SEQ += 1; }
    let _=write!(Writer,"MEM enter seq={} n={n} a0={} a1={}\n",unsafe{SEQ},a[0],a[1]); flush();
}
pub fn exit(n:usize,_:&[usize;6],ret:isize) {
    if !matches!(n,214|215|222) { return; }
    let _=write!(Writer,"MEM exit seq={} ret={ret}\n",unsafe{SEQ}); flush();
}
pub fn terminal(_:usize) {}
